edge = float(input("Enter the cube's edge: "))
surface = 6 * (edge ** 2)
print("The surface area is", surface, "square units.")
