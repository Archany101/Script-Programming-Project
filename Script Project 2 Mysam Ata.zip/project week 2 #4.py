radius = float(input("Enter the radius of the sphere "))
diameter = radius * 2
circumference = 2 * 3.14 * radius
surfacearea = 4 * 3.14 * radius**2
volume = 4/3 * 3.14 * radius**3
print ("Diameter is: ", diameter)
print ("Circumference is: ", circumference)
print ("Surface Area is: ", surfacearea)
print ("Volume is: ", volume)
