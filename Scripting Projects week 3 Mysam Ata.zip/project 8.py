velocity = 3*10**8
SecYear = 365 * 24 * 60 * 60

Lightyear = velocity * SecYear

print("The value of light year is: ", Lightyear)
