import turtle
import math


def drawCircle(turt, x, y, radius):
    turt.up()
    turt.goto(x, y + radius)
    turt.down()
    dist = (2 * math.pi * radius) / 120

    for i in range(120):
        turt.forward(dist)
        turt.right(3)



def main():
    t = turtle.Turtle()
    x = 50
    y = 75
    radius = 100
    drawCircle(t, x, y, radius)
    turtle.done()



main()

