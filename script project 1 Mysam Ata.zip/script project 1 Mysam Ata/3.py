name = "Pistol Pete"
print ("Your name is", name)
