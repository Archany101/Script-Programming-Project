B = int(input("Enter with Length"))
H = int(input("Enter with Heigt"))
area = L + W
print ("The Area is", area)
