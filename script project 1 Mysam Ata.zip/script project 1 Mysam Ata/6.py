R = float(input("Enter radius"))
area = 3.14 * R ** 2
print ("The Area is", area)
