B = int(input("Enter with base"))
H = int(input("Enter with Height"))
area = .5 * B*H
print ("The Area is", area, "Square Units")
