print("Meso Ata")
print("Garland Ave")
print("4859502982")
