x=int(input("Enter first side: "))
y= int(input("Enter second side: "))
z= int(input("Enter third side: "))
if x==y and y==z:
    print("\nThe triangle is equilateral.")
else:
    print("\nThe triangle is not equilateral.")
