side1=input('First Side: ') 
side2=input('Second Side: ') 
side3=input('Third Side: ') 
if side1==side2==side3: 
    print('This triangle is an equilateral triangle.') 
else:
    print('This triangle is not an equilateral triangle.') 
